# Python Assignment

- Explore **"Assignment - Basics of Python.pdf"** for full assignment
